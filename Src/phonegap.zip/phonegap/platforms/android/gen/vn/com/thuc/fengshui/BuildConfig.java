/** Automatically generated file. DO NOT MODIFY */
package vn.com.thuc.fengshui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}