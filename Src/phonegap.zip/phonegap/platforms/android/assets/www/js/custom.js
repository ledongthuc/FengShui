/**
 * @author Thuc
 */

$.mobile.pageContainer = $('#container');
$.mobile.defaultDialogTransition = "slide";
$.mobile.defaultPageTransition = "slide";