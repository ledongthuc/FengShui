/**
 * @author Thuc
 */

$.mobile.pageContainer = $('#container');
$.mobile.defaultDialogTransition = "none";
$.mobile.defaultPageTransition = "none";